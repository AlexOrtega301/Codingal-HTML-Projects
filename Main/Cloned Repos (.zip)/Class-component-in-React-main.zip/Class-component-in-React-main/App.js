import React from 'react';
import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <h1>Welcome to My React App 🚀</h1>
        <p>This is my custom homepage built with React.</p>
        <p>From alex to the world!!!!</p>
        <button
          className="App-button"
          onClick={() => alert('Button clicked!')}
        >
          Click Me Now.... 
        </button>
      </header>
    </div>
  );
}

export default App;
