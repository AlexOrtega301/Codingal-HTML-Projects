import './App.css';

function App() {
  return (
    <div className="App">
      <h1>Hello from React! my name is alex</h1>
      <p>My score is {10 * 9 + 10}</p>
    </div>
  );
}

export default App;
