import React, { useState } from "react";

function App() {
  const [choco, setChoco] = useState({
    name: "Dark Chocolate",
    price: 100,
    toppings: "No",
    brand: "Hershey"
  });

  const toggleChoco = () => {
    if (choco.name === "Dark Chocolate") {
      setChoco({
        name: "Milk Chocolate",
        price: 150,
        toppings: "Fruit and Nut",
        brand: "Cadbury"
      });
    } else {
      setChoco({
        name: "Dark Chocolate",
        price: 100,
        toppings: "No",
        brand: "Hershey"
      });
    }
  };

  return (
    <div className="container">
      <h1>Details of {choco.name}</h1>
      <p>My name is {choco.name}</p>
      <p>My price is {choco.price}</p>
      <p>I have {choco.toppings} toppings</p>
      <p>I’m from {choco.brand} brand</p>

      <button onClick={toggleChoco}>Change Chocolate</button>
    </div>
  );
}

export default App;
