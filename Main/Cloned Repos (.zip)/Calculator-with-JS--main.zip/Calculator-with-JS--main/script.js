//this was made by AI. pleas dont kill me. XD please look at it, and teach me it.
document.addEventListener("DOMContentLoaded", () => {
  const display = document.createElement("input");
  display.setAttribute("type", "text");
  display.setAttribute("id", "display");
  display.setAttribute("readonly", true);
  document.getElementById("calculator").prepend(display);

  let currentInput = "";
  let previousInput = "";
  let operator = null;

  const updateDisplay = () => {
    display.value = currentInput || "0";
  };

  const clearAll = () => {
    currentInput = "";
    previousInput = "";
    operator = null;
    updateDisplay();
  };

  const backspace = () => {
    currentInput = currentInput.slice(0, -1);
    updateDisplay();
  };

  const calculate = () => {
    if (previousInput && currentInput && operator) {
      const a = parseFloat(previousInput);
      const b = parseFloat(currentInput);
      switch (operator) {
        case "+":
          currentInput = (a + b).toString();
          break;
        case "-":
          currentInput = (a - b).toString();
          break;
        case "*":
          currentInput = (a * b).toString();
          break;
        case "/":
          currentInput = b !== 0 ? (a / b).toString() : "Error";
          break;
        case "%":
          currentInput = (a % b).toString();
          break;
      }
      operator = null;
      previousInput = "";
      updateDisplay();
    }
  };

  document.getElementById("keyboard").addEventListener("click", (e) => {
    const target = e.target;
    if (target.classList.contains("number")) {
      currentInput += target.id;
      updateDisplay();
    } else if (target.classList.contains("operator")) {
      switch (target.id) {
        case "clear":
          clearAll();
          break;
        case "backspace":
          backspace();
          break;
        case "=":
          calculate();
          break;
        default:
          if (currentInput) {
            if (previousInput && operator) {
              calculate();
            }
            operator = target.id;
            previousInput = currentInput;
            currentInput = "";
          }
          break;
      }
    }
  });

  updateDisplay();
});
// End of script.js - Made by Monica AI