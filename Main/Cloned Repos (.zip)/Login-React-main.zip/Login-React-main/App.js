import React, { Component } from "react";

class App extends Component {
  constructor(props) {
    super(props);


    this.ageRef = React.createRef();

    this.nameRef = React.createRef();
  }

  mysubmit = () => {
    const age = Number(this.ageRef.current.value);

    if (age >= 18) {
      alert("Login Successful");
    } else {
      alert("Not Eligible to login");
    }
  };

  render() {
    return (
      <div style={{ width: "300px", margin: "20px auto", fontFamily: "sans-serif" }}>
        <h2>Login</h2>

        <div className="form-group">
          <label>Name</label>
          <input
            type="text"
            ref={this.nameRef}
            placeholder="Enter your name"
            className="form-control"
          />
        </div>

        <div className="form-group" style={{ marginTop: "10px" }}>
          <label>Age</label>
          <input
            type="number"
            ref={this.ageRef}
            placeholder="Enter your age"
            className="form-control"
          />
        </div>

        <button
          style={{
            marginTop: "15px",
            padding: "8px 20px",
            border: "none",
            background: "#4c8bf5",
            color: "white",
            cursor: "pointer",
            borderRadius: "6px"
          }}
          onClick={this.mysubmit}
        >
          Submit
        </button>
      </div>
    );
  }
}

export default App;