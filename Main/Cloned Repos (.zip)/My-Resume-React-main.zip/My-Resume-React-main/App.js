import React from "react";
import "./index.css";

export default function App() {
return (
<div className="resume">
<h1 className="name">Alex Ortega</h1>
<p className="title">Student • YouTuber • Beginner Programmer</p>

<section className="section">
<h2>About Me</h2>
<p>
I am an 8th-grade student passionate about programming, video games, and technology. I love learning, creating, and experimenting with new ideas.
</p>
</section>

<section className="section">
<h2>Skills</h2>
<ul>
<li>Python</li>
<li>Roblox (Lua)</li>
<li>HTML and CSS</li>
<li>Scratch</li>
<li>VirtualBox</li>
<li>Basic video editing</li>
</ul>
</section>

<section className="section">
<h2>Interests</h2>
<ul>
<li>Video games (Minecraft, Roblox, Papa’s Cheeseria)</li>
<li>VMs and operating systems</li>
<li>Languages (English, French, Japanese)</li>
<li>Content creation</li>
</ul>
</section>
</div>
);
}