import React from "react";

function App() {
  return (
    <div className="resume">
      <h1 className="title">My Resume</h1>
      <p className="name">Name: Alex Ortega</p>
      <p className="role">Role: Student & Beginner Programmer</p>
      <p className="hobby">Hobby: Gaming & Coding</p>
    </div>
  );
}

export default App;
