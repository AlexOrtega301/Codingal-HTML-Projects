function myFunction() {
        var a = 4;
        alert("4 x 4 = Press the button")
        document.getElementById("demo").innerHTML = a*a;
      }