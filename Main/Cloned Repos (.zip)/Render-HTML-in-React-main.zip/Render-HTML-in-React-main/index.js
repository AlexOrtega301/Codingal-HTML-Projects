// Import React and ReactDOM
import React from 'react';
import ReactDOM from 'react-dom';

// Create a variable with HTML (JSX) for a Customer Detail table
const mycode = (
  <table border="1" cellPadding="5">
    <tr>
      <th>Customer Name</th>
      <th>Customer City</th>
      <th>Amount of Purchase</th>
    </tr>
    <tr>
      <td>Praveen</td>
      <td>Madurai</td>
      <td>12000</td>
    </tr>
    <tr>
      <td>Kumar</td>
      <td>Chennai</td>
      <td>10000</td>
    </tr>
  </table>
);

// Render the variable into the root element
ReactDOM.render(mycode, document.getElementById('root'));
