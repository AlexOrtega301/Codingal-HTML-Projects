function myFunction() {
    // Access the <title> node using two different methods and assign to <p> tags
    document.getElementById("result").innerHTML =
        document.getElementById("demo").firstChild.nodeValue;

    document.getElementById("result1").innerHTML =
        document.getElementById("demo").childNodes[0].nodeValue;
}
