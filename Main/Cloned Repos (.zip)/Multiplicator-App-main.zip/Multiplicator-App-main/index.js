import React, { useState } from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';

const MultiplyForm = () => {
  const [op1, setOp1] = useState('');
  const [op2, setOp2] = useState('');
  const [result, setResult] = useState(null);
  const [error, setError] = useState('');

  const handleMultiply = () => {
    // validation
    if (op1 === '' || op2 === '') {
      setError('⚠️ Please enter both operands.');
      setResult(null);
      return;
    }

    setError('');
    setResult(Number(op1) * Number(op2));
  };

  const handleClear = () => {
    setOp1('');
    setOp2('');
    setResult(null);
    setError('');
  };

  return (
    <div className="container">
      <h1>Advanced Multiply App</h1>
      <p className="subtitle">A simple React calculator example</p>

      <div className="form-group">
        <label>Operand 1</label>
        <input
          type="number"
          value={op1}
          onChange={(e) => setOp1(e.target.value)}
          placeholder="Enter first number"
        />
      </div>

      <div className="form-group">
        <label>Operand 2</label>
        <input
          type="number"
          value={op2}
          onChange={(e) => setOp2(e.target.value)}
          placeholder="Enter second number"
        />
      </div>

      {error && <p className="error">{error}</p>}

      {result !== null && (
        <p className="result">
          ✅ Result: <strong>{result}</strong>
        </p>
      )}

      <div className="button-group">
        <button className="btn" onClick={handleMultiply}>Multiply</button>
        <button className="btn clear" onClick={handleClear}>Clear</button>
      </div>
    </div>
  );
};

// React 18 rendering method
const root = createRoot(document.getElementById('root'));
root.render(<MultiplyForm />);