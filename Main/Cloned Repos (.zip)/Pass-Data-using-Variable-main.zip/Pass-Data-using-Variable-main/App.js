import React from 'react';

import './App.css';

class Customer extends React.Component {

render() {

return <h2>I am from {this.props.city}!</h2>;

}

}

class Details extends React.Component {

render() {

const cityname = "Alvaro Obregon";

return (

<div>

<h1>Hello</h1>

<Customer city={cityname} />

</div>

);

}

}

function App() {

return (

<div className="App">

<Details />

</div>

);

}

export default App;